import mongoose from "mongoose";

let conn = null;

export const handler = async (event) => {

  try {

    if (conn == null) {

      conn = await mongoose.connect(
        "mongodb+srv://tomaintainmyself2022_db_user:UKR56EuHkUk6Xi4R@cluster0.gipthnd.mongodb.net/studentDB",
        {
          serverSelectionTimeoutMS: 5000
        }
      );

      console.log("MongoDB connected");
    }

    const StudentSchema = new mongoose.Schema({
      name: String,
      age: Number
    });

    const Student =
      mongoose.models.Student ||
      mongoose.model("Student", StudentSchema);


    const method =
      event?.requestContext?.http?.method ||
      event?.httpMethod ||
      "GET";


    // handle preflight request (important for CORS)
    if (method === "OPTIONS") {
      return {
        statusCode: 200,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
        },
        body: ""
      };
    }


    // POST → insert student
    if (method === "POST") {

      const body = JSON.parse(event.body);

      const newStudent = await Student.create({
        name: body.name,
        age: body.age
      });

      return {
        statusCode: 200,
        headers: {
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify(newStudent)
      };

    }


    // GET → fetch students
    if (method === "GET") {

      const students = await Student.find();

      return {
        statusCode: 200,
        headers: {
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify(students)
      };

    }


    return {
      statusCode: 400,
      headers: {
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify("Unsupported method")
    };

  } catch (error) {

    console.log(error);

    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify(error.message)
    };

  }

};