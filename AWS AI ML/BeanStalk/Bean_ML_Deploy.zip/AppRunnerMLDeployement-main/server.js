require("dotenv").config();

const path = require("path");
const express = require("express");
const {
  SageMakerRuntimeClient,
  InvokeEndpointCommand,
} = require("@aws-sdk/client-sagemaker-runtime");

const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const AWS_REGION = process.env.AWS_REGION || "ap-southeast-2";
const SAGEMAKER_ENDPOINT_NAME = process.env.SAGEMAKER_ENDPOINT_NAME;

const client = new SageMakerRuntimeClient({
  region: AWS_REGION,
});

app.get("/health", (req, res) => {
  res.json({
    status: "running",
    region: AWS_REGION,
    endpoint: SAGEMAKER_ENDPOINT_NAME,
  });
});

app.post("/predict", async (req, res) => {
  try {
    const data = req.body.data;

    if (!Array.isArray(data) || data.length !== 4) {
      return res.status(400).json({
        error: "Send JSON like { data: [5.1,3.5,1.4,0.2] }",
      });
    }

    const command = new InvokeEndpointCommand({
      EndpointName: SAGEMAKER_ENDPOINT_NAME,
      ContentType: "application/json",
      Body: JSON.stringify(data),
    });

    const response = await client.send(command);

    const result = Buffer.from(response.Body).toString("utf-8");

    return res.json({
      prediction: JSON.parse(result),
    });

  } catch (error) {
    console.error(error);

    return res.status(500).json({
      error: "Prediction failed",
      details: error.message,
    });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log("Server running on port", PORT);
});
